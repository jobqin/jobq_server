//import bcrypt from 'bcryptjs';

//import jwt from 'jsonwebtoken';

//import Profileuser from '../models/user.js';
import Jobsposted_table from '../models/jobsposted.js';


const Jobsposted_insert = (req, res, next) => {
  
};



export { Jobsposted_insert };